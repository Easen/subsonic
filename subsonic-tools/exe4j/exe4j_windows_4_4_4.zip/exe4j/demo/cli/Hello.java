/*
 *   Command line application demonstration for exe4j
 */


public class Hello {
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}
